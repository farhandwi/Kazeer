# # VirtualAccountChannelCode
Virtual Account Channel Code

```php
use Xendit\PaymentRequest\VirtualAccountChannelCode;
```


    ## Enum

    
        * `BCA` (value: `'BCA'`)
    
        * `BJB` (value: `'BJB'`)
    
        * `BNI` (value: `'BNI'`)
    
        * `BRI` (value: `'BRI'`)
    
        * `MANDIRI` (value: `'MANDIRI'`)
    
        * `PERMATA` (value: `'PERMATA'`)
    
        * `BSI` (value: `'BSI'`)
    
        * `CIMB` (value: `'CIMB'`)
    
        * `SAHABAT_SAMPOERNA` (value: `'SAHABAT_SAMPOERNA'`)
    
        * `ARTAJASA` (value: `'ARTAJASA'`)
    
        * `PV` (value: `'PV'`)
    
        * `VIETCAPITAL` (value: `'VIETCAPITAL'`)
    
        * `WOORI` (value: `'WOORI'`)
    
        * `MSB` (value: `'MSB'`)
    
        * `VPB` (value: `'VPB'`)
    
        * `BIDV` (value: `'BIDV'`)
    
        * `STANDARD_CHARTERED` (value: `'STANDARD_CHARTERED'`)
    
        * `AMBANK` (value: `'AMBANK'`)
    
        * `UOB` (value: `'UOB'`)
    
        * `BNC` (value: `'BNC'`)
    
        * `HANA` (value: `'HANA'`)
    
        * `MUAMALAT` (value: `'MUAMALAT'`)
    
        * `BANK_TRANSFER` (value: `'BANK_TRANSFER'`)
    
        * `XENDIT_ENUM_DEFAULT_FALLBACK` (value: `UNKNOWN_ENUM_VALUE`)

If you encounter `UNKNOWN_ENUM_VALUE`, it means that this ENUM is unavailable in your current SDK version. Please upgrade to get the newest ENUM.

[[Back to README]](../../README.md)
